package mll.j2ee.action;

import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import mll.j2ee.bean.Person_info;
import mll.j2ee.dao.ReaderDao;
import mll.j2ee.tools.IsLogin;

public class ReaderAction extends ActionSupport {
	private Map session = ActionContext.getContext().getSession();
	private Person_info personInfo = new Person_info();
	private Person_info pi;
	private int borrow_id;

	/*
	 * 
	 * �û��鿴������Ϣ
	 */
	public String showPersonInfo() {
		borrow_id = new IsLogin().isLogin();
		if (borrow_id > 0) {
			ReaderDao db1 = new ReaderDao();
			personInfo = db1.getPersonInfo(borrow_id);
			session.put("personInfo", personInfo);
			return SUCCESS;
		} else {
			// �û�û�е�¼����ת����¼ҳ��
			return "no_login";
		}

	}

	/*
	 * 
	 * �û��޸ĸ�����Ϣ
	 */
	public String updatePersonInfo() {

		return "";
	}

	/*
	 * ��ȡҳ������
	 */
	public Person_info getPerson_info() {
		return pi;
	}

	public void setPerson_info(Person_info pi) {
		this.pi = pi;
	}
}
