package mll.j2ee.action;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class Test {

	public static void main(String[] args) {
		 //TODO Auto-generated method stub
		 Timestamp d=new Timestamp(System.currentTimeMillis()+86400000);
		 Timestamp c=new Timestamp(System.currentTimeMillis());
		 System.out.println(d);
		 SimpleDateFormat a=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		 System.out.println(a.format(d));
		 System.err.println(a.format(c));

		// Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		// BorrowDao db = new BorrowDao();
		// if (db.returnBooks(15, timestamp)) {
		// System.out.println("success");
		// } else {
		// System.out.println("error");
		// }

		/*
		 * ������ʱ���֮���ʱ���
		 */
		// Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		// System.out.println("now time=" + timestamp);
		// SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		// Timestamp beforeTime = timestamp.valueOf("2017-12-07 11:00:00");
		// System.out.println("pre time=" + beforeTime);
		// long a = timestamp.getTime() - beforeTime.getTime();
		// if (a < 0) {
		// System.out.println("С��0");
		// }
		// System.out.println(a);
		// double day = a / (1000 * 60 * 60);
		// System.out.println(day);

		// String account="meien";
		// String password="123";
		// ReaderDao db=new ReaderDao();
		// List<J2ee_reader> test=new ArrayList<>();
		// test=db.loginAction(account, password);
		// System.out.println(test.size());

		/*
		 * string to timestamp
		 */
		// Timestamp ts=new Timestamp(System.currentTimeMillis());
		// String str="2014-11-10 20:22:22";
		// System.out.println(ts);
		// System.out.println(ts.valueOf(str));

		// String string="2015-11-10";
		// Date date=new Date();
		// SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		// try {
		// date=sdf.parse(string);
		// } catch (ParseException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		//
		//
		// Add_book book=new Add_book();
		// book.setAuthor("÷��");
		// book.setBook_id("TX_1435");
		// book.setBook_name("Ӣ������");
		// book.setBook_type(3);
		// book.setPress("�ɴ������");
		// book.setPrice(5.66);
		// book.setStr_date("2015-11-11");
		// BooksDao db=new BooksDao();
		// boolean a=db.addBooks(book);
		// if(a)
		// {
		// System.out.println("success");
		// }else{
		// System.out.println("error");
		// }

	}

}
