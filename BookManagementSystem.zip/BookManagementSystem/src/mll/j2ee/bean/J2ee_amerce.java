package mll.j2ee.bean;

import java.sql.Timestamp;

/*
 * ������Ϣ��
 * */
public class J2ee_amerce {
	private int amerce_id;             //����id
	private int borrow_id;             //����ţ�����id��
	private String name;               //��������
	private String book_name;          //����
	private String book_id;            //����
	private Timestamp borrow_time;          //����ʱ��
	private Timestamp should_r_time;        //Ӧ��ʱ��
	private Timestamp return_time;          //����ʱ��
	private double fines;              //������
	public int getAmerce_id() {
		return amerce_id;
	}
	public void setAmerce_id(int amerce_id) {
		this.amerce_id = amerce_id;
	}
	public int getBorrow_id() {
		return borrow_id;
	}
	public void setBorrow_id(int borrow_id) {
		this.borrow_id = borrow_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public String getBook_id() {
		return book_id;
	}
	public void setBook_id(String book_id) {
		this.book_id = book_id;
	}
	public Timestamp getBorrow_time() {
		return borrow_time;
	}
	public void setBorrow_time(Timestamp borrow_time) {
		this.borrow_time = borrow_time;
	}
	public Timestamp getShould_r_time() {
		return should_r_time;
	}
	public void setShould_r_time(Timestamp should_r_time) {
		this.should_r_time = should_r_time;
	}
	public Timestamp getReturn_time() {
		return return_time;
	}
	public void setReturn_time(Timestamp return_time) {
		this.return_time = return_time;
	}
	public double getFines() {
		return fines;
	}
	public void setFines(double fines) {
		this.fines = fines;
	}
	
	
}
