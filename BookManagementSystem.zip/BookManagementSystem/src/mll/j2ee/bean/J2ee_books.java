package mll.j2ee.bean;

import java.sql.Timestamp;


/*
 * ͼ����Ϣ��
 * */
public class J2ee_books {
	private String str_date;
	private String book_id;                //ͼ����
	private String book_name;              //ͼ������
	private int book_type;                 //����
	private String author;                 //����
	private String press;                  //������
	private Timestamp publish_date;             //��������
	private double price;                  //����
	private Timestamp register_time;            //�Ǽ�����
	private int is_borrow;                 //�Ƿ�ɽ�
	public String getBook_id() {
		return book_id;
	}
	public void setBook_id(String book_id) {
		this.book_id = book_id;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	
	public String getStr_date() {
		return str_date;
	}
	public void setStr_date(String str_date) {
		this.str_date = str_date;
	}
	public int getBook_type() {
		return book_type;
	}
	public void setBook_type(int book_type) {
		this.book_type = book_type;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPress() {
		return press;
	}
	public void setPress(String press) {
		this.press = press;
	}
	public Timestamp getPublish_date() {
		return publish_date;
	}
	public void setPublish_date(Timestamp publish_date) {
		this.publish_date = publish_date;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Timestamp getRegister_time() {
		return register_time;
	}
	public void setRegister_time(Timestamp register_time) {
		this.register_time = register_time;
	}
	public int getIs_borrow() {
		return is_borrow;
	}
	public void setIs_borrow(int is_borrow) {
		this.is_borrow = is_borrow;
	}
	
}
