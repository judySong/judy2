package mll.j2ee.bean;

public class Register {
	private String account; // �û���
	private String student_id; // ѧ��
	private String nickname; // �ǳ�
	private String name; // ��ʵ����
	private String password; // ����
	private String comfirmPwd; // ȷ������
	private int sex; // �Ա� 1��2Ů3����

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStudent_id() {
		return student_id;
	}

	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getComfirmPwd() {
		return comfirmPwd;
	}

	public void setComfirmPwd(String comfirmPwd) {
		this.comfirmPwd = comfirmPwd;
	}

	public int getSex() {
		return sex;
	}

	public void setSex(int sex) {
		this.sex = sex;
	}

}
