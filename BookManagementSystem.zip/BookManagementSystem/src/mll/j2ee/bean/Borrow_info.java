package mll.j2ee.bean;

import java.sql.Timestamp;

public class Borrow_info {
	private int id;     //borrow��id
	private String book_id;
	private String book_name;
	private int book_type;
	private String author;
	private String press;
	private double price;
	private Timestamp borrow_time;
	private Timestamp should_r_time;
	
	public String getBook_id() {
		return book_id;
	}
	public void setBook_id(String book_id) {
		this.book_id = book_id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public int getBook_type() {
		return book_type;
	}
	public void setBook_type(int book_type) {
		this.book_type = book_type;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPress() {
		return press;
	}
	public void setPress(String press) {
		this.press = press;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Timestamp getBorrow_time() {
		return borrow_time;
	}
	public void setBorrow_time(Timestamp borrow_time) {
		this.borrow_time = borrow_time;
	}
	public Timestamp getShould_r_time() {
		return should_r_time;
	}
	public void setShould_r_time(Timestamp should_r_time) {
		this.should_r_time = should_r_time;
	}
}
