package mll.j2ee.bean;

import java.sql.Timestamp;

/*
 * ���ģ����飩��
 * */
public class J2ee_borrow {
	private int id;
	private int borrow_id;                 //����ţ�����id��
	private String book_id;                //ͼ����
	private Timestamp borrow_time;              //����ʱ��
	private Timestamp should_r_time;            //Ӧ��ʱ��
	private int is_return;                 //�Ƿ�黹
	private Timestamp return_time;              //����ʱ��
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getBorrow_id() {
		return borrow_id;
	}
	public void setBorrow_id(int borrow_id) {
		this.borrow_id = borrow_id;
	}
	public String getBook_id() {
		return book_id;
	}
	public void setBook_id(String book_id) {
		this.book_id = book_id;
	}
	public Timestamp getBorrow_time() {
		return borrow_time;
	}
	public void setBorrow_time(Timestamp borrow_time) {
		this.borrow_time = borrow_time;
	}
	public Timestamp getShould_r_time() {
		return should_r_time;
	}
	public void setShould_r_time(Timestamp should_r_time) {
		this.should_r_time = should_r_time;
	}
	public int getIs_return() {
		return is_return;
	}
	public void setIs_return(int is_return) {
		this.is_return = is_return;
	}
	public Timestamp getReturn_time() {
		return return_time;
	}
	public void setReturn_time(Timestamp return_time) {
		this.return_time = return_time;
	}
	
	
}
