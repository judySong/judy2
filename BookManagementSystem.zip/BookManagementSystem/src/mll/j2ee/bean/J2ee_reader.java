package mll.j2ee.bean;

import java.util.Date;


/*
 * ������Ϣ��
 * */
public class J2ee_reader {
	private int id;                      //����id
	private String account;              //�˺�
	private String password;             //����
	private String head_image;           //ͷ���ַ
	private String nickname;             //�ǳ�
	private int sex;                     //�Ա�
	private Date birthday;               //��������
	private String student_id;           //ѧ��
	private int borrow_number;           //��ǰ�ѽ��鱾�飨���4����
	private Date register_time;          //ע��ʱ��
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getHead_image() {
		return head_image;
	}
	public void setHead_image(String head_image) {
		this.head_image = head_image;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public int getSex() {
		return sex;
	}
	public void setSex(int sex) {
		this.sex = sex;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public String getStudent_id() {
		return student_id;
	}
	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}
	public int getBorrow_number() {
		return borrow_number;
	}
	public void setBorrow_number(int borrow_number) {
		this.borrow_number = borrow_number;
	}
	public Date getRegister_time() {
		return register_time;
	}
	public void setRegister_time(Date register_time) {
		this.register_time = register_time;
	}
	
}
