package mll.j2ee.bean;

import java.util.Date;

/*
 * ����Ա��Ϣ��
 * */
public class J2ee_master {
	private String sys_id;             //����Աid
	private String account;            //�˺�
	private String password;           //����
	private String name;               //����
	private String sex;                //�Ա�
	private Date entry_time;           //��ְʱ��
	public String getSys_id() {
		return sys_id;
	}
	public void setSys_id(String sys_id) {
		this.sys_id = sys_id;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public Date getEntry_time() {
		return entry_time;
	}
	public void setEntry_time(Date entry_time) {
		this.entry_time = entry_time;
	}
	
}
