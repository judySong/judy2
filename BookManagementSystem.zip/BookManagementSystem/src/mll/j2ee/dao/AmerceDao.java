package mll.j2ee.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import mll.j2ee.bean.J2ee_amerce;

public class AmerceDao extends Database {
	private ResultSet rs = null;
	private Statement stm = null;
	private PreparedStatement pstm = null;
	private List<J2ee_amerce> list = new ArrayList<>();

	// ���캯��
	public AmerceDao() {
		stm = getStatement();
	}

	/**
	 * ���볬ʱ������Ϣ
	 * 
	 * @param info
	 *            ����bean
	 * @return
	 */
	public boolean insertAmerceInfo(J2ee_amerce info) {
		try {
			String sql = "insert into j2ee_amerce values(?,?,?,?,?,?,?,?,?)";
			pstm = conn.prepareStatement(sql);
			// ��ֵ
			pstm.setInt(1, info.getAmerce_id());
			pstm.setInt(2, info.getBorrow_id());
			pstm.setString(3, info.getName());
			pstm.setString(4, info.getBook_name());
			pstm.setString(5, info.getBook_id());
			pstm.setTimestamp(6, info.getBorrow_time());
			pstm.setTimestamp(7, info.getShould_r_time());
			pstm.setTimestamp(8, info.getReturn_time());
			pstm.setDouble(9, info.getFines());
			// ִ��
			int res = pstm.executeUpdate();
			if (res > 0) {
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("���볬ʱ������Ϣʧ��");
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * ɾ��������Ϣ
	 * 
	 * @param amerceId
	 *            ����id��������
	 * @return
	 */
	public boolean deleteAmerceInfo(int amerceId) {
		try {
			String sql = "delete from j2ee_amerce where amerce_id=" + amerceId + "";
			int res = stm.executeUpdate(sql);
			if (res > 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("ɾ��������Ϣʧ��");
		}
		return false;
	}

	/**
	 * ��ѯ������Ϣ
	 * 
	 * @return
	 */
	public List<J2ee_amerce> getAmerceInfo() {
		try {
			String sql = "select * from j2ee_amerce";
			rs = stm.executeQuery(sql);
			while (rs.next()) {
				J2ee_amerce amerce = new J2ee_amerce();
				amerce.setAmerce_id(rs.getInt("amerce_id"));
				amerce.setBook_id(rs.getString("book_id"));
				amerce.setBook_name(rs.getString("book_name"));
				amerce.setBorrow_id(rs.getInt("borrow_id"));
				amerce.setBorrow_time(rs.getTimestamp("borrow_time"));
				amerce.setFines(rs.getDouble("fines"));
				amerce.setName(rs.getString("name"));
				amerce.setReturn_time(rs.getTimestamp("return_time"));
				amerce.setShould_r_time(rs.getTimestamp("should_r_time"));
				list.add(amerce);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("��ѯ������Ϣʧ��");
		}

		return list;
	}

}
