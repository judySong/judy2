package mll.j2ee.dao;

import java.sql.ResultSet;
import java.sql.Statement;

public class MasterDao extends Database{
	private Statement stm=null;
	private ResultSet rs=null;
	
	/*���캯��*/
	public MasterDao()
	{
		stm=getStatement();
	}
	
	/*
	 * ����Ա��¼
	 * */
	public boolean adminLogin(String account,String password)
	{
		try {
			String sql="select * from j2ee_master where account='"+account+"' and password='"+password+"'";
			rs=stm.executeQuery(sql);
			if(rs.next())
			{
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("����Ա��¼ʧ��");
		}
		return false;
	}
}
