/*
Navicat MySQL Data Transfer

Source Server         : studyMySQL
Source Server Version : 50713
Source Host           : localhost:3306
Source Database       : j2ee

Target Server Type    : MYSQL
Target Server Version : 50713
File Encoding         : 65001

Date: 2017-12-21 20:06:50
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `j2ee_amerce`
-- ----------------------------
DROP TABLE IF EXISTS `j2ee_amerce`;
CREATE TABLE `j2ee_amerce` (
  `amerce_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '借阅id（自增）',
  `borrow_id` int(11) NOT NULL COMMENT '借阅证号（读者id）',
  `name` varchar(15) NOT NULL COMMENT '读者姓名',
  `book_name` varchar(32) NOT NULL,
  `book_id` char(7) NOT NULL COMMENT '书籍编号',
  `borrow_time` datetime NOT NULL COMMENT '借书时间',
  `should_r_time` datetime NOT NULL COMMENT '应还时间',
  `return_time` datetime NOT NULL COMMENT '还书时间',
  `fines` double NOT NULL COMMENT '罚款金额',
  PRIMARY KEY (`amerce_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of j2ee_amerce
-- ----------------------------
INSERT INTO `j2ee_amerce` VALUES ('2', '2', '梅恩2', '计算机网络', 'TQ_2323', '2017-12-08 18:49:31', '2017-12-12 18:49:29', '2017-12-13 14:15:52', '4.56');
INSERT INTO `j2ee_amerce` VALUES ('3', '2', '梅恩2', '大学物理', 'ME_5353', '2017-12-08 18:49:30', '2017-12-13 18:49:29', '2017-12-14 20:27:52', '6');
INSERT INTO `j2ee_amerce` VALUES ('4', '2', '梅恩2', '计算机网络', 'TQ_2323', '2017-12-13 14:15:28', '2017-12-16 14:15:28', '2017-12-21 18:59:17', '29.759999999999998');
INSERT INTO `j2ee_amerce` VALUES ('5', '2', '梅恩2', '计算机组成原理', 'ME_3535', '2017-12-14 20:27:35', '2017-12-15 20:27:35', '2017-12-21 19:02:57', '34.08');
INSERT INTO `j2ee_amerce` VALUES ('6', '2', '梅恩2', '大学物理', 'ME_5353', '2017-12-14 20:27:36', '2017-12-15 20:27:36', '2017-12-21 19:03:02', '34.08');

-- ----------------------------
-- Table structure for `j2ee_books`
-- ----------------------------
DROP TABLE IF EXISTS `j2ee_books`;
CREATE TABLE `j2ee_books` (
  `book_id` char(7) NOT NULL COMMENT '书籍编号',
  `book_name` varchar(32) NOT NULL COMMENT '书名',
  `book_type` tinyint(1) NOT NULL COMMENT '类别（1->全部、2->文学类、3->历史类、4->悬疑类、5->心理健康类）',
  `author` varchar(32) NOT NULL COMMENT '作者',
  `press` varchar(50) NOT NULL COMMENT '出版社',
  `publish_date` date NOT NULL COMMENT '出版日期',
  `price` double NOT NULL COMMENT '价格',
  `register_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '登记日期',
  `is_borrow` tinyint(1) NOT NULL DEFAULT '4' COMMENT '是否可借（大于0可借）',
  PRIMARY KEY (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of j2ee_books
-- ----------------------------
INSERT INTO `j2ee_books` VALUES ('ME_3535', '计算机组成原理', '5', '肖西川', '十教出版社', '2015-11-10', '88.88', '2017-12-07 20:47:48', '1');
INSERT INTO `j2ee_books` VALUES ('ME_5353', '大学物理', '4', '廖欢', '成大出版社', '2017-11-11', '88.66', '2017-12-07 21:03:39', '5');
INSERT INTO `j2ee_books` VALUES ('TQ_2323', '计算机网络', '2', '梅恩', '成大出版社', '2017-12-07', '44.22', '2017-12-07 20:44:54', '6');

-- ----------------------------
-- Table structure for `j2ee_borrow`
-- ----------------------------
DROP TABLE IF EXISTS `j2ee_borrow`;
CREATE TABLE `j2ee_borrow` (
  `borrow_id` int(11) NOT NULL,
  `book_id` char(7) NOT NULL,
  `borrow_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `should_r_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_return` tinyint(1) NOT NULL DEFAULT '0',
  `return_time` timestamp NULL DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`,`borrow_id`,`book_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of j2ee_borrow
-- ----------------------------
INSERT INTO `j2ee_borrow` VALUES ('2', 'TX_1435', '2017-12-03 16:24:57', '2017-12-11 18:49:29', '1', '2017-12-03 20:52:06', '1');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TX_1435', '2017-12-03 16:25:02', '2017-12-11 18:49:29', '1', '2017-12-03 20:52:27', '2');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TX_1435', '2017-12-03 17:10:42', '2017-12-11 18:49:29', '1', '2017-12-03 20:54:54', '3');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TX_1435', '2017-12-03 20:55:18', '2017-12-11 18:49:29', '1', '2017-12-03 21:06:32', '4');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TX_1435', '2017-12-03 20:55:19', '2017-12-11 18:49:29', '1', '2017-12-03 21:06:40', '5');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TX_1435', '2017-12-03 20:57:51', '2017-12-11 18:49:29', '1', '2017-12-03 21:06:41', '6');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TX_1435', '2017-12-03 20:59:59', '2017-12-11 18:49:29', '1', '2017-12-03 21:06:43', '7');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TX_1435', '2017-12-03 21:06:09', '2017-12-11 18:49:29', '1', '2017-12-03 21:06:44', '8');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TX_1435', '2017-12-03 21:11:09', '2017-12-11 18:49:29', '1', '2017-12-03 21:11:20', '9');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TX_1435', '2017-12-03 21:11:10', '2017-12-11 18:49:29', '1', '2017-12-03 21:11:29', '10');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TX_1435', '2017-12-03 21:11:25', '2017-12-11 18:49:29', '1', '2017-12-03 21:11:32', '11');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TX_1435', '2017-12-03 21:18:37', '2017-12-11 18:49:29', '1', '2017-12-03 21:18:52', '12');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TX_1435', '2017-12-03 21:18:38', '2017-12-11 18:49:29', '1', '2017-12-03 22:09:42', '13');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TX_1435', '2017-12-03 22:09:31', '2017-12-11 18:49:29', '1', '2017-12-03 22:09:45', '14');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TX_1435', '2017-12-03 22:09:47', '2017-12-11 18:49:29', '1', '2017-12-08 10:50:24', '15');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_3535', '2017-12-08 10:55:25', '2017-12-11 18:49:29', '1', '2017-12-08 14:17:32', '17');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_5353', '2017-12-08 14:13:52', '2017-12-11 18:49:29', '1', '2017-12-08 14:17:41', '18');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TQ_2323', '2017-12-08 14:14:02', '2017-12-11 18:49:29', '1', '2017-12-08 14:14:17', '19');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TQ_2323', '2017-12-08 14:14:06', '2017-12-11 18:49:29', '1', '2017-12-08 14:16:54', '20');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_3535', '2017-12-08 14:23:18', '2017-12-11 18:49:29', '1', '2017-12-08 14:23:22', '21');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_3535', '2017-12-08 14:36:17', '2017-12-11 18:49:29', '1', '2017-12-08 14:36:29', '22');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TQ_2323', '2017-12-08 14:36:47', '2017-12-11 18:49:29', '1', '2017-12-08 14:36:56', '23');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_3535', '2017-12-08 14:37:19', '2017-12-11 18:49:29', '1', '2017-12-08 14:37:48', '24');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_3535', '2017-12-08 14:41:21', '2017-12-11 18:49:29', '1', '2017-12-08 14:56:20', '25');
INSERT INTO `j2ee_borrow` VALUES ('4', 'ME_3535', '2017-12-08 18:22:30', '2017-12-11 18:49:29', '1', '2017-12-08 18:29:23', '26');
INSERT INTO `j2ee_borrow` VALUES ('4', 'ME_3535', '2017-12-08 18:22:54', '2017-12-11 18:49:29', '1', '2017-12-08 18:29:27', '27');
INSERT INTO `j2ee_borrow` VALUES ('4', 'ME_3535', '2017-12-08 18:22:55', '2017-12-11 18:49:29', '1', '2017-12-08 18:29:29', '28');
INSERT INTO `j2ee_borrow` VALUES ('4', 'ME_3535', '2017-12-08 18:22:56', '2017-12-11 18:49:29', '1', '2017-12-08 18:29:38', '29');
INSERT INTO `j2ee_borrow` VALUES ('4', 'ME_3535', '2017-12-08 18:22:57', '2017-12-11 18:49:29', '1', '2017-12-08 18:30:00', '30');
INSERT INTO `j2ee_borrow` VALUES ('4', 'ME_3535', '2017-12-08 18:22:57', '2017-12-11 18:49:29', '1', '2017-12-08 18:30:02', '31');
INSERT INTO `j2ee_borrow` VALUES ('4', 'TQ_2323', '2017-12-08 18:30:20', '2017-12-11 18:49:29', '0', null, '32');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_3535', '2017-12-08 18:49:29', '2017-12-12 18:49:29', '1', '2017-12-08 18:53:26', '33');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_5353', '2017-12-08 18:49:30', '2017-12-13 18:49:29', '1', '2017-12-14 20:27:53', '34');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TQ_2323', '2017-12-08 18:49:31', '2017-12-12 18:49:29', '1', '2017-12-13 14:15:52', '35');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_5353', '2017-12-13 14:15:27', '2017-12-16 14:15:27', '1', '2017-12-14 20:27:56', '36');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TQ_2323', '2017-12-13 14:15:28', '2017-12-16 14:15:28', '1', '2017-12-21 18:59:18', '37');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_3535', '2017-12-14 20:27:35', '2017-12-15 20:27:35', '1', '2017-12-21 19:02:58', '38');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_5353', '2017-12-14 20:27:36', '2017-12-15 20:27:36', '1', '2017-12-21 19:03:03', '39');
INSERT INTO `j2ee_borrow` VALUES ('2', 'TQ_2323', '2017-12-14 20:27:37', '2017-12-15 20:27:37', '0', null, '40');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_2123', '2017-12-14 20:29:41', '2017-12-15 20:29:41', '1', '2017-12-14 20:29:46', '41');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_5353', '2017-12-21 18:59:04', '2017-12-22 18:59:04', '0', null, '42');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_3535', '2017-12-21 19:02:23', '2017-12-22 19:02:23', '0', null, '43');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_3535', '2017-12-21 19:02:23', '2017-12-22 19:02:23', '0', null, '44');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_3535', '2017-12-21 19:02:24', '2017-12-22 19:02:24', '0', null, '45');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_3535', '2017-12-21 19:02:24', '2017-12-22 19:02:24', '0', null, '46');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_3535', '2017-12-21 19:02:25', '2017-12-22 19:02:25', '0', null, '47');
INSERT INTO `j2ee_borrow` VALUES ('2', 'ME_3535', '2017-12-21 19:02:25', '2017-12-20 19:02:25', '0', null, '48');

-- ----------------------------
-- Table structure for `j2ee_master`
-- ----------------------------
DROP TABLE IF EXISTS `j2ee_master`;
CREATE TABLE `j2ee_master` (
  `sys_id` char(6) NOT NULL,
  `account` varchar(15) NOT NULL,
  `password` varchar(18) NOT NULL,
  `name` varchar(15) NOT NULL,
  `sex` char(1) NOT NULL,
  `entry_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sys_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of j2ee_master
-- ----------------------------
INSERT INTO `j2ee_master` VALUES ('103616', 'meien', '123', '梅恩', '男', '2017-12-01 16:32:35');

-- ----------------------------
-- Table structure for `j2ee_reader`
-- ----------------------------
DROP TABLE IF EXISTS `j2ee_reader`;
CREATE TABLE `j2ee_reader` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户id（自增）',
  `account` varchar(15) NOT NULL,
  `password` varchar(18) NOT NULL,
  `head_image` varchar(150) DEFAULT NULL,
  `nickname` varchar(15) DEFAULT NULL,
  `sex` tinyint(1) DEFAULT NULL COMMENT '1男2女3保密',
  `birthday` date DEFAULT NULL,
  `student_id` varchar(15) DEFAULT NULL,
  `borrow_number` tinyint(1) NOT NULL DEFAULT '0',
  `register_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `name` varchar(15) NOT NULL COMMENT '用户真实名字',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of j2ee_reader
-- ----------------------------
INSERT INTO `j2ee_reader` VALUES ('1', 'meien1', '123456', null, null, null, null, null, '0', '2017-12-01 11:33:56', '梅恩1');
INSERT INTO `j2ee_reader` VALUES ('2', 'meien', '123', 'images/p1.jpg', '测试昵称', '3', null, '123123', '8', '2017-12-01 11:46:25', '梅恩2');
INSERT INTO `j2ee_reader` VALUES ('3', 'test', '123', null, null, null, null, null, '0', '2017-12-01 12:20:37', '梅恩3');
INSERT INTO `j2ee_reader` VALUES ('4', '2323', '123', null, '么', '2', null, '563', '1', '2017-12-03 17:16:43', '梅恩4');
INSERT INTO `j2ee_reader` VALUES ('5', 'test', '12', null, 'meien', '3', null, '12', '0', '2017-12-03 17:17:26', '梅恩5');
INSERT INTO `j2ee_reader` VALUES ('6', 'meien', '23', null, 'me;lk', '1', null, '5435', '0', '2017-12-03 17:18:03', '梅恩6');
INSERT INTO `j2ee_reader` VALUES ('7', '232323', '12', null, '么', '1', null, '563', '0', '2017-12-03 17:19:10', '梅恩7');
INSERT INTO `j2ee_reader` VALUES ('8', 'xxc', '123', null, null, '3', null, '232', '0', '2017-12-08 12:03:33', '肖西川');
INSERT INTO `j2ee_reader` VALUES ('9', 'meien4343', '123123', null, null, '3', null, '2353', '0', '2017-12-21 19:00:22', 'test');
